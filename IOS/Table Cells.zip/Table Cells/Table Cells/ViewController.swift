//
//  ViewController.swift
//  Table Cells
//
//  Created by MacStudent on 2017-08-11.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    let cellTableIdentifier = "CellTableIdentifier"
    
    @IBOutlet weak var tableView: UITableView!
    let computers = [
        ["Name" : "MacBook Air", "Color" : "Silver"],
        ["Name" : "MacBook Pro", "Color" : "Silver"],
        ["Name" : "iMac", "Color" : "Silver"],
        ["Name" : "Mac Mini", "Color" : "Silver"],
        ["Name" : "Mac Pro", "Color" : "Black"]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(NameAndColorCell.self,
                                forCellReuseIdentifier: cellTableIdentifier)
        
        let nib = UINib(nibName: "NameAndColorCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: cellTableIdentifier)
        tableView.rowHeight = 65
    }
    
     func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return computers.count
    }
    
     func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(
            withIdentifier: cellTableIdentifier, for: indexPath as IndexPath)
                as! NameAndColorCell
        
            let rowData = computers[indexPath.row]
            cell.name = rowData["Name"]!
            cell.color = rowData["Color"]!
            
            return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

