//
//  ViewController.swift
//  HelloWorld
//
//  Created by MacStudent on 2017-07-28.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbGreeting: UILabel!
    
    @IBOutlet weak var lbGreeting2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tfEditing(_ sender: UITextField) {
       lbGreeting.text = "Hello \(sender.text!)"
    }

   
    @IBAction func tdEditEnded(_ sender: UITextField) {
        lbGreeting2.text = "\(sender.text!)"
    }
}

