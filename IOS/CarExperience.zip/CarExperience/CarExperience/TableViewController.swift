//
//  TableViewController.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit

//Controller responsible for the Second Tab of the App. This controller is a table, so inherits from UITableViewController and it has a search bar, then UISearchResultsUpdating.
class TableViewController: UITableViewController, UISearchResultsUpdating {
    
    //Initialize the variables.
    var feedbackArr = [CarFeedback]()
    var filteredArr = [CarFeedback]()
    var database: OpaquePointer?
    var searchController = UISearchController()
    var resultsController = UITableViewController()

    //First method of the life cycle, initialize search controller.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchController = UISearchController(searchResultsController: resultsController)
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchResultsUpdater = self
        searchController.searchBar.placeholder = "Search for address"
        resultsController.tableView.delegate = self
        resultsController.tableView.dataSource = self
        
        self.title = "Search"
       
    }
    
    //When view will appear to the user, load new values from the database and show on the screen.
    override func viewWillAppear(_ animated: Bool) {
        if openDB() {
            loadAll()
        }
        
        //navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    //Update screen to show only the items that contains the string searched by the user. Match the store address with the user input and reload data.
    func updateSearchResults(for searchController: UISearchController) {
        let text = searchController.searchBar.text!
        
        filteredArr = feedbackArr.filter( { return $0.storeAddress.lowercased().contains(text.lowercased())} )
        
        resultsController.tableView.reloadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    // Number of rows in the table.
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == resultsController.tableView {
            return filteredArr.count
        } else {
            return feedbackArr.count
        }
    }
    
    //Height of the rows in the table.
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0;
    }

    //Instantiating each cell of the table. Create a CustomCell and fill the attributes, then return the cell.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell") as! CustomCell
        
        var name = ""
        var storeAddress = ""
        var rating = 1
        
        if tableView == resultsController.tableView {
            name = filteredArr[indexPath.row].name
            storeAddress = filteredArr[indexPath.row].storeAddress
            rating = filteredArr[indexPath.row].rating
        } else {
            name = feedbackArr[indexPath.row].name
            storeAddress = feedbackArr[indexPath.row].storeAddress
            rating = feedbackArr[indexPath.row].rating
        }
        
        cell.lbStoreAddress.text = storeAddress
        cell.lbName.text = name
        cell.lbRating.text = "\(rating)"
        
        tableView.separatorInset.left = tableView.separatorInset.right

        return cell
    }
    
    
    
    //Fired when used selects a cell, get the array value of the cell and show the details screen.
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var feedback: CarFeedback
        
        if tableView == resultsController.tableView {
            feedback = filteredArr[indexPath.row]
        } else {
            feedback = feedbackArr[indexPath.row]
        }
        
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "feedbackDetails") as! DetailsViewController
        
        secondViewController.carFeedback = feedback
        
        self.navigationController?.pushViewController(secondViewController, animated: true)
        
        self.dismiss(animated: false, completion: nil)
    }
    
    //Open the database.
    func openDB() -> Bool{
        let result = sqlite3_open(dataFilePath(), &database)
        if result != SQLITE_OK {
            sqlite3_close(database)
            print("Failed to open database")
            return false;
        }
        
        return true;
        
    }
    
    
    //Get the application path for the database
    func dataFilePath() -> String {
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("db.sqlite")
        
        return fileURL.path
    }
    
    //Load all the users feedback in the database to the local array feedbackArr and reload the screen data.
    func loadAll(){
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, "SELECT * FROM UX", -1, &statement, nil) == SQLITE_OK {
            feedbackArr = [CarFeedback]()
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let feedback = CarFeedback()
                
                let id = sqlite3_column_int64(statement, 0)
                let name = String(cString: sqlite3_column_text(statement, 1))
                let age = sqlite3_column_int64(statement, 2)
                let license = String(cString: sqlite3_column_text(statement, 3))
                let address = String(cString: sqlite3_column_text(statement, 4))
                let storeAddress = String(cString: sqlite3_column_text(statement, 5))
                let vehicleName = String(cString: sqlite3_column_text(statement, 6))
                let description = String(cString: sqlite3_column_text(statement, 7))
                let location = String(cString: sqlite3_column_text(statement, 8))
                let photo = String(cString: sqlite3_column_text(statement, 9))
                let rating = sqlite3_column_int64(statement, 10)
                
                feedback.id = Int(id);
                feedback.name = name
                feedback.age = Int(age)
                feedback.driverLicense = license
                feedback.address = address
                feedback.storeAddress = storeAddress
                feedback.vehicleName = vehicleName
                feedback.description = description
                feedback.location = location
                feedback.photo = photo
                feedback.rating = Int(rating)
                
                
                feedbackArr.append(feedback)
                
                
            }
            
        } else {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("error preparing select: \(errmsg)")
        }
        
        
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        
        tableView.reloadData()
        resultsController.tableView.reloadData()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
