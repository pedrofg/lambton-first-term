//
//  TableViewController.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, UISearchResultsUpdating {
    
    var feedbackArr = [CarFeedback]()
    var filteredArr = [CarFeedback]()
    var database: OpaquePointer?
    var searchController = UISearchController()
    var resultsController = UITableViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchController = UISearchController(searchResultsController: resultsController)
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchResultsUpdater = self
        searchController.searchBar.placeholder = "Search for address"
        resultsController.tableView.delegate = self
        resultsController.tableView.dataSource = self
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if openDB() {
            loadAll()
        }
        
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        let text = searchController.searchBar.text!
        
        filteredArr = feedbackArr.filter( { return $0.storeAddress.lowercased().contains(text.lowercased())} )
        
        resultsController.tableView.reloadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == resultsController.tableView {
            return filteredArr.count
        } else {
            return feedbackArr.count
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0;
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell") as! CustomCell
        
        var name = ""
        var storeAddress = ""
        var rating = 1
        
        if tableView == resultsController.tableView {
            name = filteredArr[indexPath.row].name
            storeAddress = filteredArr[indexPath.row].storeAddress
            rating = filteredArr[indexPath.row].rating
        } else {
            name = feedbackArr[indexPath.row].name
            storeAddress = feedbackArr[indexPath.row].storeAddress
            rating = feedbackArr[indexPath.row].rating
        }
        
        cell.lbStoreAddress.text = storeAddress
        cell.lbName.text = name
        cell.lbRating.text = "\(rating)"

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var feedback: CarFeedback
        
        if tableView == resultsController.tableView {
            feedback = filteredArr[indexPath.row]
        } else {
            feedback = feedbackArr[indexPath.row]
        }
        
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "feedbackDetails") as! DetailsViewController
        
        secondViewController.carFeedback = feedback
        
        self.navigationController?.pushViewController(secondViewController, animated: true)
        
        self.dismiss(animated: false, completion: nil)
    }
    
    func openDB() -> Bool{
        let result = sqlite3_open(dataFilePath(), &database)
        if result != SQLITE_OK {
            sqlite3_close(database)
            print("Failed to open database")
            return false;
        }
        
        return true;
        
    }
    
    
    func dataFilePath() -> String {
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("db.sqlite")
        
        return fileURL.path
    }
    
    func loadAll(){
        var statement:OpaquePointer? = nil
        if sqlite3_prepare_v2(database, "SELECT * FROM UX", -1, &statement, nil) == SQLITE_OK {
            feedbackArr = [CarFeedback]()
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let feedback = CarFeedback()
                
                let id = sqlite3_column_int64(statement, 0)
                let name = String(cString: sqlite3_column_text(statement, 1))
                let age = sqlite3_column_int64(statement, 2)
                let license = String(cString: sqlite3_column_text(statement, 3))
                let address = String(cString: sqlite3_column_text(statement, 4))
                let storeAddress = String(cString: sqlite3_column_text(statement, 5))
                let vehicleName = String(cString: sqlite3_column_text(statement, 6))
                let description = String(cString: sqlite3_column_text(statement, 7))
                let location = String(cString: sqlite3_column_text(statement, 8))
                let photo = String(cString: sqlite3_column_text(statement, 9))
                let rating = sqlite3_column_int64(statement, 10)
                
                feedback.id = Int(id);
                feedback.name = name
                feedback.age = Int(age)
                feedback.driverLicense = license
                feedback.address = address
                feedback.storeAddress = storeAddress
                feedback.vehicleName = vehicleName
                feedback.description = description
                feedback.location = location
                feedback.photo = photo
                feedback.rating = Int(rating)
                
                
                feedbackArr.append(feedback)
                
                
            }
            
        } else {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("error preparing select: \(errmsg)")
        }
        
        
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        
        tableView.reloadData()
        resultsController.tableView.reloadData()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
