//
//  CarFeedback.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit

class CarFeedback {
    
    private var _id: Int = 0;
    private var _name = ""
    private var _age = 0
    private var _driverLicense = ""
    private var _address = ""
    private var _storeAddress = ""
    private var _vehicleName = ""
    private var _description = ""
    private var _location = ""
    private var _photo = ""
    private var _rating = 1
    
    
    
    var id:Int {
        get {
            return _id
        }
        set (newVal) {
            self._id = newVal
        }
    }
    
    var rating:Int {
        get {
            return _rating
        }
        set (newVal) {
            self._rating = newVal
        }
    }
    
    var name:String {
        get {
            return _name
        }
        set (newVal) {
            self._name = newVal
        }
    }
    
    var age:Int {
        get {
            return _age
        }
        set (newVal) {
            self._age = newVal
        }
    }
    
    var driverLicense:String {
        get {
            return _driverLicense
        }
        set (newVal) {
            self._driverLicense = newVal
        }
    }
    
    var address:String {
        get {
            return _address
        }
        set (newVal) {
            self._address = newVal
        }
    }
    
    var storeAddress:String {
        get {
            return _storeAddress
        }
        set (newVal) {
            self._storeAddress = newVal
        }
    }
    
    var vehicleName:String {
        get {
            return _vehicleName
        }
        set (newVal) {
            self._vehicleName = newVal
        }
    }
    
    var description:String {
        get {
            return _description
        }
        set (newVal) {
            self._description = newVal
        }
    }
    
    var location:String {
        get {
            return _location
        }
        set (newVal) {
            self._location = newVal
        }
    }
    var photo:String {
        get {
            return _photo
        }
        set (newVal) {
            self._photo = newVal
        }
    }

}
