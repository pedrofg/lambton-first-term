//
//  CustomCell.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit

//Class create a new table cell customized. Inherits from UITableViewCell, IOS Class to represents a table cell.
class CustomCell: UITableViewCell {

    //Just defined the fields coming from the storyboard which will be set by the TableViewController.
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbStoreAddress: UILabel!
    @IBOutlet weak var lbRating: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
}
