//
//  DetailsViewController.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit
import MapKit

class DetailsViewController: UIViewController {
    
    var carFeedback: CarFeedback?

    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbAge: UILabel!
    @IBOutlet weak var lbVehicle: UILabel!
    @IBOutlet weak var lbDescription: UILabel!
    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        openMapForPlace()
        lbName.text = carFeedback!.name
        lbAge.text = String(carFeedback!.age)
        lbVehicle.text = carFeedback!.vehicleName
        lbDescription.text = carFeedback!.description
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func openMapForPlace() {
        var locationArr = carFeedback!.location.components(separatedBy: "/")
        
        if locationArr[0].isEmpty || locationArr[1].isEmpty {
            return
        }
        
        let latitude: CLLocationDegrees = CLLocationDegrees(Float(locationArr[0])!)
        let longitude: CLLocationDegrees = CLLocationDegrees(Float(locationArr[1])!)
        
        let center = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        map.setRegion(region, animated: true)
        
        // Drop a pin at user's Current Location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        myAnnotation.title = "Store"
        map.addAnnotation(myAnnotation)
    }

}
