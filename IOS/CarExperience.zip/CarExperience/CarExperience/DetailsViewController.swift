//
//  DetailsViewController.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit
import MapKit

//Basic Controller to show the details of the selected user experience.
class DetailsViewController: UIViewController {
    
    //Initialize car feedback to be received from the previous controller.
    var carFeedback: CarFeedback?

    //Create the Outlets defined by the storyboard.
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbAge: UILabel!
    @IBOutlet weak var lbVehicle: UILabel!
    @IBOutlet weak var lbDescription: UILabel!
    @IBOutlet weak var lbRating: UILabel!
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var lbAddress: UILabel!
    @IBOutlet weak var imgVehicle: UIImageView!
    
    //Load the screen values with the received object.
    override func viewDidLoad() {
        super.viewDidLoad()

        openMapForPlace()
        lbName.text = carFeedback!.name
        lbAge.text = String(carFeedback!.age)
        lbVehicle.text = carFeedback!.vehicleName
        lbDescription.text = carFeedback!.description
        lbRating.text = String(carFeedback!.rating)
        lbAddress.text = String(carFeedback!.storeAddress)
        
        
        //Load Image From database string64
//        if !carFeedback!.photo.isEmpty && carFeedback!.photo != "photo"{
//            let dataDecoded : Data = Data(base64Encoded: carFeedback!.photo, options: .ignoreUnknownCharacters)!
//            let decodedimage = UIImage(data: dataDecoded)
//            imgVehicle.image = decodedimage
//        }
        
        loadImage()
        
        self.title = carFeedback!.name
    }
    
    //Load the image path into the image component. Default IOS way to do that.
    func loadImage(){
        let fileManager = FileManager.default
        let imagePAth = carFeedback!.photo
        if fileManager.fileExists(atPath: imagePAth){
            imgVehicle.image = UIImage(contentsOfFile: imagePAth)
        }
    }
    
    //Hide navigation bar, just for design purpose.
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Load the lat and long into the map, default IOS way to do that. Create CLLocationDegrees with the lat and long and pass them to the CLLocationCoordinate2D.
    func openMapForPlace() {
        var locationArr = carFeedback!.location.components(separatedBy: "/")
        
        if locationArr[0].isEmpty || locationArr[1].isEmpty {
            return
        }
        
        let latitude: CLLocationDegrees = CLLocationDegrees(Float(locationArr[0])!)
        let longitude: CLLocationDegrees = CLLocationDegrees(Float(locationArr[1])!)
        
        let center = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        map.setRegion(region, animated: true)
        
        // Drop a pin at user's Current Location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        myAnnotation.title = "Store"
        map.addAnnotation(myAnnotation)
    }

}
