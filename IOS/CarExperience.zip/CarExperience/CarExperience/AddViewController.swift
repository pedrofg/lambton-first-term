//
//  AddViewController.swift
//  CarExperience
//
//  Created by Pedro Guimarães fernandes on 2017-08-14.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class AddViewController: UIViewController, CLLocationManagerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    

    
    var locationManager:CLLocationManager!
    var lat = ""
    var long = ""
    var rating = 1
    
    var imagePicker = UIImagePickerController()
    var database: OpaquePointer?
    var imageDb = "";
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var txtLocation: UITextField!
    @IBOutlet weak var txtDescription: UITextField!
    @IBOutlet weak var txtVehicleName: UITextField!
    @IBOutlet weak var txtStoreAddress: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtDriverLicense: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var pickerRating: UIPickerView!
    
    internal let SQLITE_STATIC = unsafeBitCast(0, to: sqlite3_destructor_type.self)
    internal let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
    
     var pickerData = ["1","2","3","4","5"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        
        self.pickerRating.delegate = self
        self.pickerRating.dataSource = self
        
        
        if openDB() {
            createDB(database: database);
        }
    
        
        
        tabBarController?.tabBar.barTintColor = hexStringToUIColor(hex: "4DB6AC")
        tabBarController?.tabBar.tintColor = hexStringToUIColor(hex: "FFFFFF")
        tabBarController?.tabBar.unselectedItemTintColor = hexStringToUIColor(hex: "#757575")

    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func openDB() -> Bool{
        let result = sqlite3_open(dataFilePath(), &database)
        if result != SQLITE_OK {
            sqlite3_close(database)
            print("Failed to open database")
            return false;
        } else {
            print("Database opened")
            return true;
        }
    }
    
    
    func dataFilePath() -> String {
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("db.sqlite")
        
        return fileURL.path
    }
    
    func createDB(database : OpaquePointer?){
        
        let createSQL = "CREATE TABLE IF NOT EXISTS UX " +
        "(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, AGE INTEGER, LICENSE TEXT, ADDRESS TEXT, STORE_ADDRESS TEXT, VEHICLE_NAME TEXT, DESCRIPTION TEXT, LOCATION TEXT, PHOTO TEXT, RATING INTEGER);"
        
        let result = sqlite3_exec(database, createSQL, nil, nil, nil)
        if (result != SQLITE_OK) {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("Failed to create table: \(errmsg)")
        } else {
            print("Table created")
        }
        
        
    }
    
    func validateFields() -> String{
        let name = txtName.text!;
        let age = Int(txtAge.text!);
        let license = txtDriverLicense.text!
        let address = txtAddress.text!
        let storeAddress = txtStoreAddress.text!
        let vehicleName = txtVehicleName.text!
        let description = txtDescription.text!
        
        var error = ""
        
        if name.isEmpty {
            error = "Name"
        }
        else if age == nil {
            error = "Age"
        }
        else if license.isEmpty {
            error = "License"
        }
        else if address.isEmpty {
            error = "Address"
        }
        else if storeAddress.isEmpty {
            error = "Store Address"
        }
        else if vehicleName.isEmpty {
            error = "Vehicle Name"
        }
        else if description.isEmpty {
            error = "Description"
        }
        else if lat.isEmpty || long.isEmpty {
            error = "Location"
        }
        
        
        return error;
    }
    
    @IBAction func saveClickListener(_ sender: UIButton) {
        let name = txtName.text!;
        let age = txtAge.text!;
        let license = txtDriverLicense.text!
        let address = txtAddress.text!
        let storeAddress = txtStoreAddress.text!
        let vehicleName = txtVehicleName.text!
        let description = txtDescription.text!
        let location = lat + "/" + long
        
        let validate = validateFields()
        
        if !validate.isEmpty {
            error(field: validate)
            return;
        }
    
        
        let update = "INSERT OR REPLACE INTO UX (NAME, AGE, LICENSE, ADDRESS, STORE_ADDRESS, VEHICLE_NAME, DESCRIPTION, LOCATION, PHOTO, RATING) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        var statement:OpaquePointer? = nil
        
        
        if sqlite3_prepare_v2(database, update, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("error preparing insert: \(errmsg)")
            
        }
        
        if sqlite3_bind_text(statement, 1, name, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding name: \(errmsg)")
            error(field: "Name")
        }
        
        if sqlite3_bind_int(statement, 2, Int32(age)!) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding age: \(errmsg)")
            error(field: "Age")
        }
        if sqlite3_bind_text(statement, 3, license, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding license: \(errmsg)")
            error(field: "License")
        }
        if sqlite3_bind_text(statement, 4, address, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding address: \(errmsg)")
            error(field: "Address")
        }
        if sqlite3_bind_text(statement, 5, storeAddress, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding storeAddress: \(errmsg)")
            error(field: "Store Address")
        }
        if sqlite3_bind_text(statement, 6, vehicleName, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding vehicleName: \(errmsg)")
            error(field: "Vehicle Name")
        }
        if sqlite3_bind_text(statement, 7, description, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding description: \(errmsg)")
            error(field: "Description")
        }
        if sqlite3_bind_text(statement, 8, location, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding location: \(errmsg)")
            error(field: "Location")
        }
        if sqlite3_bind_text(statement, 9, imageDb, -1, SQLITE_TRANSIENT) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding photo: \(errmsg)")
            error(field: "Photo")
        }
        
        if sqlite3_bind_int(statement, 10, Int32(rating)) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("failure binding age: \(errmsg)")
            error(field: "Rating")
        }
        
        
        if sqlite3_step(statement) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("Error inserting to table: \(errmsg)")
        }
        
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(database)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        
        success();
        
    }
    
    func error(field: String){
        
        let alert = UIAlertController(title: "Error", message: "\(field) Invalid", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func success(){
        txtName.text = ""
        txtAge.text = ""
        txtDriverLicense.text = ""
        txtAddress.text = ""
        txtStoreAddress.text = ""
        txtVehicleName.text = ""
        txtDescription.text = ""
        txtLocation.text = ""
        
        let alert = UIAlertController(title: "Success", message: "Thank you for your feedback", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.default, handler: { action in
            
            self.tabBarController?.selectedIndex = 1
            
            
        }))
        
        self.present(alert, animated: true, completion: nil)

    }
    
    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    @available(iOS 2.0, *)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    // Catpure the picker view selection
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        rating = Int(pickerData[row])!
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func addPictureClickListener(_ sender: UIButton) {
        
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: - Done image capture here
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        imageView.contentMode = .scaleAspectFit //3
        imageView.image = chosenImage //4
        
        let imageData:NSData = UIImagePNGRepresentation(chosenImage)! as NSData
        imageDb = imageData.base64EncodedString(options: .lineLength64Characters)
        
        
//        let image             = info[UIImagePickerControllerOriginalImage] as! UIImage
//        let imageUrl          = info[UIImagePickerControllerReferenceURL] as? NSURL
//        let imageName         = imageUrl?.lastPathComponent
//        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
//        let photoURL          = NSURL(fileURLWithPath: documentDirectory)
//        let localPath         = photoURL.appendingPathComponent(imageName!)
//        
//        if !FileManager.default.fileExists(atPath: localPath!.path) {
//            do {
//                try UIImageJPEGRepresentation(image, 1.0)?.write(to: localPath!)
//                print("file saved")
//            }catch {
//                print("error saving file")
//            }
//        }
//        else {
//            print("file already exists")
//        }
        
        dismiss(animated:true, completion: nil) //5
    }

    
    
    
    @IBAction func currentLocationClickListener(_ sender: UIButton) {
        addMyCurrentLocation()
    }
    
    
    func addMyCurrentLocation() {
        if lat.isEmpty {
            locationManager = CLLocationManager()
            locationManager.delegate = self as CLLocationManagerDelegate
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
        
            if CLLocationManager.locationServicesEnabled() {
                locationManager.startUpdatingLocation()
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        
        locationManager.stopUpdatingLocation()
        
        print("user latitude = \(userLocation.coordinate.latitude)")
        print("user longitude = \(userLocation.coordinate.longitude)")
        lat = String(userLocation.coordinate.latitude)
        long = String(userLocation.coordinate.longitude)

        txtLocation.text = "Lat: \(lat), Long: \(long)";
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        print("Error \(error)")
    }

}
